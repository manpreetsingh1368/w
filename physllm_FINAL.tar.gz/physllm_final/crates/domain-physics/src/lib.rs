pub mod constants;
pub mod chemistry;
pub mod units;
pub mod astrophysics;

pub use constants::{PhysicalConstant, ConstantsDB};
pub use chemistry::{ChemicalFormula, atomic_weight};
pub use astrophysics::AstroObject;

use thiserror::Error;

#[derive(Debug, Error)]
pub enum DomainError {
    #[error("Unknown element: {0}")]
    UnknownElement(String),
    #[error("Parse error: {0}")]
    ParseError(String),
    #[error("Constant not found: {0}")]
    ConstantNotFound(String),
}
pub type Result<T> = std::result::Result<T, DomainError>;
