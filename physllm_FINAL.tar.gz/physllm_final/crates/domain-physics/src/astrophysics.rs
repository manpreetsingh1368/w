use serde::{Deserialize, Serialize};
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AstroObject {
    pub name:     String,
    pub kind:     AstroKind,
    pub ra_deg:   Option<f64>,
    pub dec_deg:  Option<f64>,
    pub distance: Option<f64>,
    pub redshift: Option<f64>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AstroKind {
    Star, Galaxy, Nebula, BlackHole, NeutronStar, Pulsar,
    Quasar, Cluster, Planet, Exoplanet,
}

pub fn schwarzschild_radius(mass_kg: f64) -> f64 {
    2.0 * 6.674_30e-11 * mass_kg / (299_792_458.0f64).powi(2)
}
pub fn planck_function(wavelength_m: f64, temperature_k: f64) -> f64 {
    let h = 6.626_070_15e-34;
    let c = 299_792_458.0f64;
    let k = 1.380_649e-23;
    let exp = (h * c / (wavelength_m * k * temperature_k)).exp() - 1.0;
    if exp <= 0.0 { return 0.0; }
    2.0 * h * c * c / wavelength_m.powi(5) / exp
}
