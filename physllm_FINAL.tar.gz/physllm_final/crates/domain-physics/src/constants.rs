use std::collections::HashMap;
use crate::{DomainError, Result};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhysicalConstant {
    pub symbol:      String,
    pub name:        String,
    pub value:       f64,
    pub uncertainty: f64,
    pub unit:        String,
}

impl PhysicalConstant {
    pub fn relative_uncertainty(&self) -> f64 {
        if self.value.abs() > 0.0 { self.uncertainty / self.value.abs() } else { 0.0 }
    }
}

pub struct ConstantsDB {
    by_symbol: HashMap<String, PhysicalConstant>,
}

impl ConstantsDB {
    pub fn built_in() -> Self {
        let data: &[(&str, &str, f64, f64, &str)] = &[
            ("c",      "speed of light in vacuum",        299_792_458.0,      0.0,          "m s^-1"),
            ("h",      "Planck constant",                 6.626_070_15e-34,   0.0,          "J s"),
            ("hbar",   "reduced Planck constant",         1.054_571_817e-34,  0.0,          "J s"),
            ("G",      "Newtonian gravitational constant", 6.674_30e-11,       0.000_15e-11, "m^3 kg^-1 s^-2"),
            ("kB",     "Boltzmann constant",              1.380_649e-23,      0.0,          "J K^-1"),
            ("NA",     "Avogadro constant",               6.022_140_76e23,    0.0,          "mol^-1"),
            ("R",      "molar gas constant",              8.314_462_618,      0.0,          "J mol^-1 K^-1"),
            ("e",      "elementary charge",               1.602_176_634e-19,  0.0,          "C"),
            ("me",     "electron mass",                   9.109_383_7015e-31, 2.8e-40,      "kg"),
            ("mp",     "proton mass",                     1.672_621_923_69e-27,5.1e-37,     "kg"),
            ("sigma",  "Stefan-Boltzmann constant",       5.670_374_419e-8,   0.0,          "W m^-2 K^-4"),
            ("alpha",  "fine-structure constant",         7.297_352_5693e-3,  1.1e-12,      "1"),
            ("a0",     "Bohr radius",                     5.291_772_109_03e-11,8.0e-21,     "m"),
            ("muB",    "Bohr magneton",                   9.274_010_0783e-24, 2.8e-33,      "J T^-1"),
            ("Msun",   "solar mass",                      1.988_416e30,       3.0e27,       "kg"),
            ("Rsun",   "solar radius",                    6.957e8,            1.0e6,        "m"),
            ("Lsun",   "solar luminosity",                3.828e26,           5.0e23,       "W"),
            ("au",     "astronomical unit",               1.495_978_707e11,   0.0,          "m"),
            ("ly",     "light year",                      9.460_730_472e15,   0.0,          "m"),
            ("pc",     "parsec",                          3.085_677_581e16,   6.0e7,        "m"),
            ("H0",     "Hubble constant (Planck 2018)",   67.4,               0.5,          "km s^-1 Mpc^-1"),
            ("eps0",   "vacuum electric permittivity",    8.854_187_8128e-12, 1.3e-21,      "F m^-1"),
            ("mu0",    "vacuum magnetic permeability",    1.256_637_062_12e-6,1.9e-16,      "N A^-2"),
        ];
        let mut by_symbol = HashMap::new();
        for &(sym, name, val, unc, unit) in data {
            by_symbol.insert(sym.to_string(), PhysicalConstant {
                symbol: sym.to_string(), name: name.to_string(),
                value: val, uncertainty: unc, unit: unit.to_string(),
            });
        }
        Self { by_symbol }
    }

    pub fn get(&self, symbol: &str) -> Result<&PhysicalConstant> {
        self.by_symbol.get(symbol)
            .ok_or_else(|| DomainError::ConstantNotFound(symbol.into()))
    }

    pub fn all(&self) -> impl Iterator<Item = &PhysicalConstant> {
        self.by_symbol.values()
    }
}
