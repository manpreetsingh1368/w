use crate::{DomainError, Result};
use std::collections::HashMap;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChemicalFormula {
    pub raw:      String,
    pub elements: HashMap<String, u32>,
}

impl ChemicalFormula {
    pub fn parse(formula: &str) -> Result<Self> {
        let elements = parse_formula(formula)?;
        Ok(Self { raw: formula.to_string(), elements })
    }

    pub fn molecular_weight(&self) -> Result<f64> {
        let mut mw = 0.0f64;
        for (element, &count) in &self.elements {
            let aw = atomic_weight(element)
                .ok_or_else(|| DomainError::UnknownElement(element.clone()))?;
            mw += aw * count as f64;
        }
        Ok(mw)
    }

    pub fn hill_notation(&self) -> String {
        let mut parts: Vec<(String, u32)> = self.elements.iter()
            .map(|(k, &v)| (k.clone(), v)).collect();
        parts.sort_by(|(a, _), (b, _)| {
            let rank = |s: &str| match s { "C" => 0, "H" => 1, _ => 2 };
            rank(a).cmp(&rank(b)).then(a.cmp(b))
        });
        parts.iter().map(|(e, n)| if *n == 1 { e.clone() } else { format!("{e}{n}") })
            .collect::<String>()
    }
}

fn parse_formula(s: &str) -> Result<HashMap<String, u32>> {
    let mut result = HashMap::new();
    let chars: Vec<char> = s.chars().collect();
    parse_segment(&chars, 0, &mut result)?;
    Ok(result)
}

fn parse_segment(chars: &[char], mut i: usize, acc: &mut HashMap<String, u32>) -> Result<usize> {
    while i < chars.len() {
        match chars[i] {
            '(' => {
                let mut sub = HashMap::new();
                i = parse_segment(chars, i + 1, &mut sub)?;
                if i >= chars.len() || chars[i] != ')' {
                    return Err(DomainError::ParseError("unmatched '('".into()));
                }
                i += 1;
                let (n, new_i) = read_number(chars, i);
                i = new_i;
                for (el, cnt) in sub { *acc.entry(el).or_insert(0) += cnt * n.max(1); }
            }
            ')' => return Ok(i),
            c if c.is_uppercase() => {
                let (elem, new_i) = read_element(chars, i);
                i = new_i;
                let (n, new_i) = read_number(chars, i);
                i = new_i;
                *acc.entry(elem).or_insert(0) += n.max(1);
            }
            _ => { i += 1; }
        }
    }
    Ok(i)
}

fn read_element(chars: &[char], start: usize) -> (String, usize) {
    let mut s = chars[start].to_string();
    let mut i = start + 1;
    while i < chars.len() && chars[i].is_lowercase() { s.push(chars[i]); i += 1; }
    (s, i)
}

fn read_number(chars: &[char], start: usize) -> (u32, usize) {
    let mut s = String::new();
    let mut i = start;
    while i < chars.len() && chars[i].is_ascii_digit() { s.push(chars[i]); i += 1; }
    (s.parse().unwrap_or(0), i)
}

pub fn atomic_weight(symbol: &str) -> Option<f64> {
    match symbol {
        "H"  => Some(1.008),   "He" => Some(4.002602), "Li" => Some(6.94),
        "Be" => Some(9.0122),  "B"  => Some(10.81),    "C"  => Some(12.011),
        "N"  => Some(14.007),  "O"  => Some(15.999),   "F"  => Some(18.998),
        "Ne" => Some(20.180),  "Na" => Some(22.990),   "Mg" => Some(24.305),
        "Al" => Some(26.982),  "Si" => Some(28.085),   "P"  => Some(30.974),
        "S"  => Some(32.06),   "Cl" => Some(35.45),    "Ar" => Some(39.948),
        "K"  => Some(39.098),  "Ca" => Some(40.078),   "Fe" => Some(55.845),
        "Cu" => Some(63.546),  "Zn" => Some(65.38),    "Br" => Some(79.904),
        "Ag" => Some(107.868), "I"  => Some(126.904),  "Au" => Some(196.967),
        "Hg" => Some(200.592), "Pb" => Some(207.2),    "U"  => Some(238.029),
        _ => None,
    }
}
