pub const KERNEL_NAMES: &[&str] = &[
    "flash_attention_kernel", "rope_kernel", "layer_norm_kernel",
    "softmax_f16", "kv_cache_append",
];
