pub mod device;
pub mod tensor;
pub mod ops;
pub mod memory;
pub mod kernels;

pub use device::GpuDevice;
pub use tensor::DeviceTensor;
pub use memory::MemoryPool;
pub use ops::{matmul_f16, flash_attention, rope_embed, rms_norm};

use thiserror::Error;

#[derive(Debug, Error)]
pub enum BackendError {
    #[error("HIP error {code}: {msg}")]
    Hip { code: i32, msg: String },
    #[error("GPU device not found: {0}")]
    DeviceNotFound(String),
    #[error("Out of GPU memory: requested {requested_mb}MB, available {available_mb}MB")]
    OutOfMemory { requested_mb: usize, available_mb: usize },
    #[error("Kernel launch failed: {0}")]
    KernelLaunch(String),
    #[error("Shape mismatch: {0}")]
    ShapeMismatch(String),
}

pub type Result<T> = std::result::Result<T, BackendError>;

// Include generated (or stub) HIP bindings
#[cfg(any(feature = "rocm", feature = "cpu-only"))]
pub mod hip_ffi {
    include!(concat!(env!("OUT_DIR"), "/hip_bindings.rs"));
}
