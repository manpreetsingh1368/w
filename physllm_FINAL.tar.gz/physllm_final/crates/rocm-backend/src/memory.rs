// memory.rs
use crate::Result;
pub struct MemoryPool { total: usize, used: usize, base: *mut u8 }
unsafe impl Send for MemoryPool {}
unsafe impl Sync for MemoryPool {}
impl MemoryPool {
    pub fn new(size_mb: usize) -> Result<Self> {
        let total = size_mb * 1024 * 1024;
        let layout = std::alloc::Layout::from_size_align(total, 256).unwrap();
        let base = unsafe { std::alloc::alloc(layout) };
        Ok(Self { total, used: 0, base })
    }
    pub fn used_mb(&self)  -> usize { self.used  / (1024*1024) }
    pub fn total_mb(&self) -> usize { self.total / (1024*1024) }
}
impl Drop for MemoryPool {
    fn drop(&mut self) {
        if !self.base.is_null() {
            let layout = std::alloc::Layout::from_size_align(self.total, 256).unwrap();
            unsafe { std::alloc::dealloc(self.base, layout); }
        }
    }
}
