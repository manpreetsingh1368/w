use crate::{BackendError, Result};
use std::sync::Arc;
use parking_lot::Mutex;
use tracing::{info, warn};

#[derive(Debug, Clone)]
pub struct GpuProperties {
    pub device_id:     i32,
    pub name:          String,
    pub gfx_arch:      String,
    pub vram_total_mb: usize,
    pub compute_units: u32,
    pub wavefront_size: u32,
}

struct RawStream(*mut std::ffi::c_void);
unsafe impl Send for RawStream {}
unsafe impl Sync for RawStream {}

pub struct GpuDevice {
    pub props:  GpuProperties,
    _stream:    Arc<Mutex<RawStream>>,
}

impl std::fmt::Debug for GpuDevice {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "GpuDevice({})", self.props.name)
    }
}

impl GpuDevice {
    pub fn open_best() -> Result<Self> { Self::open(0) }

    pub fn open(idx: i32) -> Result<Self> {
        #[cfg(feature = "rocm")]
        unsafe {
            use crate::hip_ffi::*;
            let err = hipSetDevice(idx);
            if err != 0 { return Err(BackendError::Hip { code: err, msg: format!("hipSetDevice({idx})") }); }
            let mut props: hipDeviceProp_tR0600 = hipDeviceProp_tR0600::default();
            hipGetDeviceProperties_v2(&mut props, idx);
            let name = std::ffi::CStr::from_ptr(props.name.as_ptr()).to_string_lossy().to_string();
            let arch = std::ffi::CStr::from_ptr(props.gcnArchName.as_ptr()).to_string_lossy().to_string();
            info!("GPU[{idx}]: {name} ({arch}) {} MB", props.totalGlobalMem / 1_048_576);
            let mut stream: hipStream_t = std::ptr::null_mut();
            hipStreamCreate(&mut stream);
            return Ok(GpuDevice {
                props: GpuProperties {
                    device_id: idx, name, gfx_arch: arch,
                    vram_total_mb: props.totalGlobalMem / 1_048_576,
                    compute_units: props.multiProcessorCount as u32,
                    wavefront_size: props.warpSize as u32,
                },
                _stream: Arc::new(Mutex::new(RawStream(stream as *mut _))),
            });
        }

        #[cfg(feature = "cpu-only")]
        {
            warn!("cpu-only mode: GPU operations will be emulated on CPU");
            Ok(GpuDevice {
                props: GpuProperties {
                    device_id: -1,
                    name: "CPU (cpu-only mode)".into(),
                    gfx_arch: "none".into(),
                    vram_total_mb: 0,
                    compute_units: rayon::current_num_threads() as u32,
                    wavefront_size: 0,
                },
                _stream: Arc::new(Mutex::new(RawStream(std::ptr::null_mut()))),
            })
        }
    }

    pub fn synchronise(&self) -> Result<()> {
        #[cfg(feature = "rocm")]
        unsafe {
            use crate::hip_ffi::*;
            let s = self._stream.lock();
            let err = hipStreamSynchronize(s.0 as hipStream_t);
            if err != 0 { return Err(BackendError::Hip { code: err, msg: "hipStreamSynchronize".into() }); }
        }
        Ok(())
    }

    pub fn raw_stream(&self) -> *mut std::ffi::c_void {
        self._stream.lock().0
    }
}
