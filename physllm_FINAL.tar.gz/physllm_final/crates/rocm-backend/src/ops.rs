use crate::{DeviceTensor, GpuDevice, BackendError, Result};
use half::f16;

pub fn matmul_f16(dev: &GpuDevice, a: &DeviceTensor<f16>, b: &DeviceTensor<f16>, c: &mut DeviceTensor<f16>) -> Result<()> {
    let m = a.rows(); let k = a.cols(); let n = b.cols();
    if b.rows() != k { return Err(BackendError::ShapeMismatch(format!("matmul: a.cols({k}) != b.rows({})", b.rows()))); }
    // CPU fallback: naive O(m*k*n)
    let a_h = a.copy_to_host()?;
    let b_h = b.copy_to_host()?;
    let mut c_h = vec![0.0f32; m * n];
    for i in 0..m { for j in 0..n { for l in 0..k { c_h[i*n+j] += a_h[i*k+l].to_f32() * b_h[l*n+j].to_f32(); } } }
    let c_f16: Vec<f16> = c_h.iter().map(|&x| f16::from_f32(x)).collect();
    c.copy_from_host(&c_f16)
}

pub fn flash_attention(dev: &GpuDevice, q: &DeviceTensor<f16>, k: &DeviceTensor<f16>, v: &DeviceTensor<f16>, out: &mut DeviceTensor<f16>, scale: f32, causal: bool) -> Result<()> {
    let seq = q.shape().get(q.shape().len().saturating_sub(2)).copied().unwrap_or(1);
    let d   = *q.shape().last().unwrap_or(&0);
    let q_h: Vec<f32> = q.copy_to_host()?.iter().map(|x| x.to_f32()).collect();
    let k_h: Vec<f32> = k.copy_to_host()?.iter().map(|x| x.to_f32()).collect();
    let v_h: Vec<f32> = v.copy_to_host()?.iter().map(|x| x.to_f32()).collect();
    let mut o_h = vec![0f32; q.numel()];
    for i in 0..seq {
        let mut scores = vec![f32::NEG_INFINITY; seq];
        for j in 0..seq {
            if causal && j > i { continue; }
            scores[j] = (0..d).map(|dd| q_h[i*d+dd] * k_h[j*d+dd]).sum::<f32>() * scale;
        }
        let max = scores.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        let exp: Vec<f32> = scores.iter().map(|&s| (s - max).exp()).collect();
        let sum: f32 = exp.iter().sum();
        for dd in 0..d { o_h[i*d+dd] = (0..seq).map(|j| exp[j] / sum * v_h[j*d+dd]).sum(); }
    }
    let o_f16: Vec<f16> = o_h.iter().map(|&x| f16::from_f32(x)).collect();
    out.copy_from_host(&o_f16)
}

pub fn rope_embed(dev: &GpuDevice, q: &mut DeviceTensor<f16>, k: &mut DeviceTensor<f16>, offset: usize, theta: f32) -> Result<()> {
    let apply = |t: &mut DeviceTensor<f16>| -> Result<()> {
        let hd  = *t.shape().last().unwrap_or(&0);
        let seq = t.shape().get(t.shape().len().saturating_sub(2)).copied().unwrap_or(1);
        let mut h: Vec<f32> = t.copy_to_host()?.iter().map(|x| x.to_f32()).collect();
        for s in 0..seq {
            let pos = (s + offset) as f32;
            for i in 0..hd/2 {
                let freq = pos / theta.powf(2.0 * i as f32 / hd as f32);
                let (sin, cos) = freq.sin_cos();
                let idx = s * hd + i * 2;
                if idx + 1 < h.len() {
                    let (x0, x1) = (h[idx], h[idx+1]);
                    h[idx]   = x0 * cos - x1 * sin;
                    h[idx+1] = x0 * sin + x1 * cos;
                }
            }
        }
        let f16s: Vec<f16> = h.iter().map(|&x| f16::from_f32(x)).collect();
        t.copy_from_host(&f16s)
    };
    apply(q)?; apply(k)
}

pub fn rms_norm(dev: &GpuDevice, x: &mut DeviceTensor<f16>, weight: &DeviceTensor<f16>, eps: f32) -> Result<()> {
    let d = x.cols();
    let mut h: Vec<f32> = x.copy_to_host()?.iter().map(|v| v.to_f32()).collect();
    let w: Vec<f32> = weight.copy_to_host()?.iter().map(|v| v.to_f32()).collect();
    for row in h.chunks_mut(d) {
        let rms = (row.iter().map(|&v| v*v).sum::<f32>() / d as f32 + eps).sqrt();
        for (i, v) in row.iter_mut().enumerate() { *v = *v / rms * w.get(i).copied().unwrap_or(1.0); }
    }
    let f16s: Vec<f16> = h.iter().map(|&x| f16::from_f32(x)).collect();
    x.copy_from_host(&f16s)
}
