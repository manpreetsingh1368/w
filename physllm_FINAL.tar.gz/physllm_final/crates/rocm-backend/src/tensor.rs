// tensor.rs
use crate::{BackendError, Result};
use half::f16;
use std::marker::PhantomData;

pub trait Element: Copy + bytemuck::Pod + Send + Sync + 'static {}
impl Element for f16 {}
impl Element for f32 {}
impl Element for f64 {}
impl Element for u8  {}
impl Element for i32 {}
impl Element for u32 {}
impl Element for i64 {}

pub struct DeviceTensor<T: Element> {
    ptr:     *mut T,
    shape:   Vec<usize>,
    numel:   usize,
    _marker: PhantomData<T>,
}

unsafe impl<T: Element> Send for DeviceTensor<T> {}
unsafe impl<T: Element> Sync for DeviceTensor<T> {}

impl<T: Element> DeviceTensor<T> {
    pub fn alloc(shape: &[usize]) -> Result<Self> {
        let numel = shape.iter().product::<usize>();
        let ptr = if numel == 0 { std::ptr::null_mut() } else { alloc_mem::<T>(numel)? };
        Ok(Self { ptr, shape: shape.to_vec(), numel, _marker: PhantomData })
    }

    pub fn from_slice(data: &[T], shape: &[usize]) -> Result<Self> {
        assert_eq!(data.len(), shape.iter().product::<usize>(), "slice/shape mismatch");
        let mut t = Self::alloc(shape)?;
        if !t.ptr.is_null() {
            unsafe { std::ptr::copy_nonoverlapping(data.as_ptr(), t.ptr, data.len()); }
        }
        Ok(t)
    }

    pub fn copy_from_host(&mut self, data: &[T]) -> Result<()> {
        assert_eq!(data.len(), self.numel);
        if !self.ptr.is_null() {
            unsafe { std::ptr::copy_nonoverlapping(data.as_ptr(), self.ptr, data.len()); }
        }
        Ok(())
    }

    pub fn copy_to_host(&self) -> Result<Vec<T>> {
        let mut out = vec![T::zeroed(); self.numel];
        if !self.ptr.is_null() {
            unsafe { std::ptr::copy_nonoverlapping(self.ptr, out.as_mut_ptr(), self.numel); }
        }
        Ok(out)
    }

    pub fn shape(&self)  -> &[usize] { &self.shape }
    pub fn numel(&self)  -> usize    { self.numel }
    pub fn raw_ptr(&self) -> *mut T  { self.ptr }
    pub fn rows(&self)   -> usize    { if self.shape.len() >= 2 { self.shape[self.shape.len()-2] } else { 1 } }
    pub fn cols(&self)   -> usize    { *self.shape.last().unwrap_or(&0) }
}

impl<T: Element> Drop for DeviceTensor<T> {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            unsafe { let _ = Vec::from_raw_parts(self.ptr, self.numel, self.numel); }
        }
    }
}

trait Zeroed: Sized { fn zeroed() -> Self; }
impl<T: bytemuck::Zeroable> Zeroed for T { fn zeroed() -> Self { bytemuck::Zeroable::zeroed() } }

fn alloc_mem<T>(n: usize) -> Result<*mut T> {
    let mut v = Vec::<T>::with_capacity(n);
    unsafe { v.set_len(n); }
    let ptr = v.as_mut_ptr();
    std::mem::forget(v);
    Ok(ptr)
}
