use std::{env, path::PathBuf, process::Command};

fn main() {
    // Always emit these so cargo knows what to watch
    println!("cargo:rerun-if-env-changed=ROCM_PATH");
    println!("cargo:rerun-if-env-changed=HIP_PATH");

    let rocm_path = env::var("ROCM_PATH")
        .or_else(|_| env::var("HIP_PATH"))
        .unwrap_or_else(|_| "/opt/rocm".to_string());

    // Kernel dir: CARGO_MANIFEST_DIR is crates/rocm-backend/
    // kernels/ is at workspace root → go up two levels
    let manifest = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let kernel_dir = manifest.join("../../kernels");
    let kernel_dir = kernel_dir.canonicalize().unwrap_or_else(|_| {
        std::fs::create_dir_all(&kernel_dir).ok();
        kernel_dir
    });

    for kernel in KERNELS {
        println!("cargo:rerun-if-changed={}", kernel_dir.join(kernel).display());
    }

    #[cfg(feature = "rocm")]
    {
        let out = PathBuf::from(env::var("OUT_DIR").unwrap());
        ensure_kernels(&kernel_dir);
        compile_kernels(&rocm_path, &kernel_dir, &out);
        generate_bindings(&rocm_path, &out);

        println!("cargo:rustc-link-search=native={rocm_path}/lib");
        println!("cargo:rustc-link-lib=dylib=amdhip64");
        println!("cargo:rustc-link-lib=dylib=rocblas");
        println!("cargo:rustc-link-lib=dylib=hipblas");
    }

    #[cfg(feature = "cpu-only")]
    {
        let out = PathBuf::from(env::var("OUT_DIR").unwrap());
        write_stub_bindings(&out);
    }
}

const KERNELS: &[&str] = &[
    "gemm_f16.hip", "flash_attention.hip", "softmax.hip",
    "rope_embedding.hip", "layer_norm.hip", "kv_cache.hip",
];

const ARCHES: &[&str] = &[
    "gfx1100", "gfx1030", "gfx906", "gfx90a", "gfx942",
];

#[cfg(feature = "rocm")]
fn compile_kernels(rocm_path: &str, kernel_dir: &PathBuf, out: &PathBuf) {
    let hipcc = format!("{rocm_path}/bin/hipcc");
    if !std::path::Path::new(&hipcc).exists() {
        eprintln!("cargo:warning=hipcc not found at {hipcc}");
        return;
    }
    let mut objs = Vec::new();
    for kernel in KERNELS {
        let src = kernel_dir.join(kernel);
        if !src.exists() { eprintln!("cargo:warning=missing: {}", src.display()); continue; }
        let obj = out.join(kernel.replace(".hip", ".o"));
        let mut args: Vec<String> = ARCHES.iter().map(|a| format!("--offload-arch={a}")).collect();
        args.extend(["-O3".into(), "-ffast-math".into(), "-fPIC".into(),
                     format!("-I{rocm_path}/include"), "-c".into(), "-x".into(), "hip".into(),
                     src.to_string_lossy().into(), "-o".into(), obj.to_string_lossy().into()]);
        match Command::new(&hipcc).args(&args).status() {
            Ok(s) if s.success() => { objs.push(obj); }
            Ok(s) => eprintln!("cargo:warning=hipcc failed ({s}) for {kernel}"),
            Err(e) => eprintln!("cargo:warning=cannot run hipcc: {e}"),
        }
    }
    if !objs.is_empty() {
        let lib = out.join("libphysllm_kernels.a");
        if Command::new("ar").arg("rcs").arg(&lib).args(&objs).status().map(|s| s.success()).unwrap_or(false) {
            println!("cargo:rustc-link-search=native={}", out.display());
            println!("cargo:rustc-link-lib=static=physllm_kernels");
        }
    }
}

#[cfg(feature = "rocm")]
fn generate_bindings(rocm_path: &str, out: &PathBuf) {
    let header = format!("{rocm_path}/include/hip/hip_runtime_api.h");
    if !std::path::Path::new(&header).exists() {
        eprintln!("cargo:warning=HIP header not found — using stubs");
        write_stub_bindings(out); return;
    }
    let gcc_ver = detect_gcc_version();
    let gcc_inc = format!("/usr/lib/gcc/x86_64-linux-gnu/{gcc_ver}/include");
    let builder = bindgen::Builder::default()
        .header(&header)
        .clang_arg(format!("-I{rocm_path}/include"))
        .clang_arg(format!("--gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/{gcc_ver}"))
        .clang_arg(format!("-isystem{gcc_inc}"))
        .clang_arg("-isystem/usr/include/x86_64-linux-gnu")
        .clang_arg("-isystem/usr/include")
        .allowlist_function("hip.*")
        .allowlist_function("hipblas.*")
        .allowlist_type("hip.*")
        .allowlist_type("hipblas.*")
        .allowlist_var("HIP.*")
        .allowlist_recursively(false)
        .derive_debug(true)
        .derive_default(true);
    match builder.generate() {
        Ok(b) => b.write_to_file(out.join("hip_bindings.rs")).expect("write bindings"),
        Err(e) => { eprintln!("cargo:warning=bindgen failed: {e}"); write_stub_bindings(out); }
    }
}

fn detect_gcc_version() -> String {
    let out = Command::new("gcc").arg("-dumpmajorversion").output().ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .unwrap_or_default();
    let v = out.trim().to_string();
    if !v.is_empty() { return v; }
    if let Ok(rd) = std::fs::read_dir("/usr/lib/gcc/x86_64-linux-gnu/") {
        let mut vs: Vec<String> = rd.filter_map(|e| e.ok())
            .filter_map(|e| { let n = e.file_name().to_string_lossy().into_owned();
                if n.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) { Some(n) } else { None }})
            .collect();
        vs.sort(); if let Some(v) = vs.last() { return v.clone(); }
    }
    "13".to_string()
}

fn ensure_kernels(kernel_dir: &PathBuf) {
    std::fs::create_dir_all(kernel_dir).ok();
    let stubs: &[(&str, &str)] = &[
        ("gemm_f16.hip",  "#include <hip/hip_runtime.h>\nextern \"C\" void gemm_f16_noop(void) {}\n"),
        ("softmax.hip",   SOFTMAX_SRC),
        ("kv_cache.hip",  KV_CACHE_SRC),
    ];
    for (name, src) in stubs {
        let p = kernel_dir.join(name);
        if !p.exists() { std::fs::write(&p, src).ok(); }
    }
}

fn write_stub_bindings(out: &PathBuf) {
    std::fs::write(out.join("hip_bindings.rs"), HIP_STUBS).expect("write stubs");
}

const HIP_STUBS: &str = r#"
pub type hipStream_t     = *mut ::std::os::raw::c_void;
pub type hipblasHandle_t = *mut ::std::os::raw::c_void;
#[repr(C)] #[derive(Debug, Clone)]
pub struct hipDeviceProp_tR0600 {
    pub name:               [::std::os::raw::c_char; 256],
    pub gcnArchName:        [::std::os::raw::c_char; 256],
    pub totalGlobalMem:     usize,
    pub multiProcessorCount:i32,
    pub warpSize:           i32,
    pub maxThreadsPerBlock: i32,
}
#[allow(non_camel_case_types)]
#[repr(u32)] #[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum hipMemcpyKind { hipMemcpyHostToDevice=1, hipMemcpyDeviceToHost=2, hipMemcpyDeviceToDevice=3 }
#[allow(non_camel_case_types)]
#[repr(u32)] #[derive(Debug, Clone, Copy)]
pub enum hipblasOperation_t { HIPBLAS_OP_N=111, HIPBLAS_OP_T=112 }
pub use hipblasOperation_t::*;
extern "C" {
    pub fn hipSetDevice(id: i32) -> i32;
    pub fn hipGetDeviceProperties_v2(p: *mut hipDeviceProp_tR0600, id: i32) -> i32;
    pub fn hipStreamCreate(s: *mut hipStream_t) -> i32;
    pub fn hipStreamDestroy(s: hipStream_t) -> i32;
    pub fn hipStreamSynchronize(s: hipStream_t) -> i32;
    pub fn hipMalloc(ptr: *mut *mut ::std::os::raw::c_void, size: usize) -> i32;
    pub fn hipFree(ptr: *mut ::std::os::raw::c_void) -> i32;
    pub fn hipMemcpy(dst: *mut ::std::os::raw::c_void, src: *const ::std::os::raw::c_void, size: usize, kind: hipMemcpyKind) -> i32;
    pub fn hipMemGetInfo(free: *mut usize, total: *mut usize) -> i32;
    pub fn hipblasCreate(h: *mut hipblasHandle_t) -> i32;
    pub fn hipblasDestroy(h: hipblasHandle_t) -> i32;
    pub fn hipblasHgemm(h: hipblasHandle_t, ta: hipblasOperation_t, tb: hipblasOperation_t,
        m: i32, n: i32, k: i32,
        alpha: *const half::f16, A: *const half::f16, lda: i32,
        B: *const half::f16, ldb: i32,
        beta: *const half::f16, C: *mut half::f16, ldc: i32) -> i32;
}
"#;

const SOFTMAX_SRC: &str = r#"
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <float.h>
#define WS 64
__device__ float wmax(float v){for(int m=WS/2;m>0;m>>=1)v=fmaxf(v,__shfl_xor(v,m));return v;}
__device__ float wsum(float v){for(int m=WS/2;m>0;m>>=1)v+=__shfl_xor(v,m);return v;}
__global__ void softmax_k(__half* x,int rows,int cols){
    int row=blockIdx.x; if(row>=rows)return;
    __half* r=x+row*cols;
    float mx=-FLT_MAX;
    for(int i=threadIdx.x;i<cols;i+=blockDim.x)mx=fmaxf(mx,__half2float(r[i]));
    mx=wmax(mx);
    float s=0;
    for(int i=threadIdx.x;i<cols;i+=blockDim.x){float e=expf(__half2float(r[i])-mx);r[i]=__float2half(e);s+=e;}
    s=wsum(s);
    for(int i=threadIdx.x;i<cols;i+=blockDim.x)r[i]=__float2half(__half2float(r[i])/s);
}
extern "C" void softmax_f16(hipStream_t s,__half* x,int rows,int cols){
    hipLaunchKernelGGL(softmax_k,dim3(rows),dim3(WS),0,s,x,rows,cols);}
"#;

const KV_CACHE_SRC: &str = r#"
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
__global__ void kv_append_k(__half* cache,const __half* nkv,int batch,int heads,int ms,int hd,int off,int nt){
    long idx=(long)blockIdx.x*blockDim.x+threadIdx.x;
    if(idx>=(long)batch*heads*nt*hd)return;
    int d=idx%hd,tok=(idx/hd)%nt,h=(idx/hd/nt)%heads,b=idx/hd/nt/heads;
    cache[((long)(b*heads+h)*ms+(off+tok))*hd+d]=nkv[idx];
}
extern "C" void kv_cache_append(hipStream_t s,__half* cache,const __half* nkv,
    int batch,int heads,int ms,int hd,int off,int nt){
    long tot=(long)batch*heads*nt*hd;
    hipLaunchKernelGGL(kv_append_k,dim3((tot+255)/256),dim3(256),0,s,cache,nkv,batch,heads,ms,hd,off,nt);}
"#;
