# PhysLLM — Physics & Chemistry AI

A full LLM system for physics, chemistry, astrophysics and astrochemistry.
Built in Rust with AMD ROCm GPU support, live web search, physics simulations,
voice interaction, and a web interface.

---

## First: install Rust properly

The system Rust from `apt` is too old (1.75). You need 1.80+.

```bash
# Remove old Rust if installed via apt
sudo apt remove -y rustc cargo 2>/dev/null || true

# Install via rustup (official, always latest stable)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source ~/.cargo/env

# Verify (should be 1.80 or newer)
rustc --version
```

---

## Install system dependencies

```bash
sudo apt update && sudo apt install -y \
    build-essential \
    libssl-dev \
    libclang-dev \
    clang \
    pkg-config \
    git
```

---

## Build — CPU only (no GPU required)

```bash
cd physllm

# Build everything
cargo build --release

# Run the API server
./target/release/physllm-server

# Open the web interface
firefox index.html
# or: python3 -m http.server 3000  then open http://localhost:3000
```

Test it works:
```bash
curl http://localhost:8080/v1/health
curl http://localhost:8080/v1/constants/hbar
curl -X POST http://localhost:8080/v1/chemistry/mw \
     -H "Content-Type: application/json" \
     -d '{"formula":"H2O"}'
```

---

## Build — AMD GPU (ROCm)

```bash
# Verify ROCm is installed
rocminfo | grep gfx

# Set your ROCm path (adjust version number)
export ROCM_PATH=/opt/rocm-7.2.0   # or /opt/rocm

# Fix for bindgen limits.h error
export BINDGEN_EXTRA_CLANG_ARGS="-isystem/usr/lib/gcc/x86_64-linux-gnu/$(gcc -dumpmajorversion)/include"

# Build with ROCm
cargo build --release --features rocm

# Run
ROCM_PATH=/opt/rocm-7.2.0 ./target/release/physllm-server
```

---

## Build — Voice interaction (optional)

Requires additional system packages:

```bash
sudo apt install -y libasound2-dev

# Build voice features
cargo build --release --features "voice-io/audio"

# For full voice (Whisper STT + VAD):
# 1. Build whisper.cpp first:
cd vendor/whisper.cpp
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)
cd ../..

# 2. Download a Whisper model:
mkdir -p models/whisper
wget -O models/whisper/ggml-small.en.bin \
  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin

# 3. Download Silero VAD:
wget -O models/silero_vad.onnx \
  https://github.com/snakers4/silero-vad/raw/master/files/silero_vad.onnx

# 4. Build with full voice
cargo build --release --features "voice-io/full"
```

---

## Load a pretrained model

By default the server runs with random weights (for testing the API).
To use a real model:

```bash
# Download Mistral 7B (Apache 2.0, no restrictions)
pip install huggingface_hub
huggingface-cli download mistralai/Mistral-7B-v0.1 \
    --local-dir models/mistral-7b \
    --include "*.safetensors" "config.json" "tokenizer.json"

# Run with weights
MODEL_DIR=models/mistral-7b ./target/release/physllm-server
```

---

## Train on physics data

```bash
# 1. Prepare data
python3 scripts/prepare_data.py \
    --raw-dir data/raw \
    --out-dir data/train

# 2. Train (LoRA fine-tune)
./scripts/train.sh --model mistral-7b --steps 10000
```

---

## Project structure

```
physllm/
├── Cargo.toml                   # workspace
├── index.html                   # web interface (open in browser)
├── kernels/                     # AMD GPU HIP kernels
│   ├── flash_attention.hip
│   ├── gemm_f16.hip
│   ├── kv_cache.hip
│   ├── layer_norm.hip
│   ├── rope_embedding.hip
│   └── softmax.hip
├── crates/
│   ├── domain-physics/          # NIST constants, chemistry, astrophysics
│   ├── rocm-backend/            # AMD GPU layer (CPU fallback included)
│   ├── web-search/              # arXiv, NIST, NASA ADS, PubChem search
│   ├── llm-core/                # Transformer forward pass, tokenizer
│   ├── sim-agent/               # 7 physics simulation engines
│   ├── api-server/              # REST + WebSocket API server
│   ├── trainer/                 # LoRA fine-tuning with real autograd
│   └── voice-io/                # Whisper STT + Piper TTS pipeline
├── configs/
│   └── physllm_7b.json          # model hyperparameters
└── scripts/
    ├── prepare_data.py          # training data preparation
    ├── train.sh                 # training launcher
    ├── setup_voice.sh           # download voice models
    └── voice_client.html        # browser voice interface
```

---

## API endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /v1/health | Server status |
| POST | /v1/generate | Text generation |
| POST | /v1/generate/search | Generation with web search |
| POST | /v1/simulate | Run a physics simulation |
| POST | /v1/search | Search scientific databases |
| POST | /v1/search/arxiv | Search arXiv papers |
| POST | /v1/fetch | Fetch and extract a URL |
| GET | /v1/constants/:symbol | Look up a physical constant |
| POST | /v1/chemistry/mw | Molecular weight calculator |
| WS | /v1/voice | Voice interaction (WebSocket) |

---

## Common build errors

**`error: requires rustc 1.80`**
→ Upgrade Rust: `rustup update stable`

**`limits.h not found`** (bindgen/ROCm)
→ `export BINDGEN_EXTRA_CLANG_ARGS="-isystem/usr/lib/gcc/x86_64-linux-gnu/$(gcc -dumpmajorversion)/include"`

**`gemm_f16.hip not found`**
→ Already in `kernels/` directory — no action needed

**`hipcc not found`**
→ `export ROCM_PATH=/opt/rocm-7.2.0` (use your actual version)

---

## Supported AMD GPUs

| GPU | Architecture | VRAM | Best for |
|-----|-------------|------|---------|
| RX 7900 XTX | gfx1100 | 24 GB | 13B model f16 |
| RX 7900 XT | gfx1100 | 20 GB | 13B model f16 |
| RX 6900 XT | gfx1030 | 16 GB | 7B model f16 |
| RX 6800 XT | gfx1030 | 16 GB | 7B model f16 |
| Instinct MI300X | gfx942 | 192 GB | 120B model |

---

## License

MIT
